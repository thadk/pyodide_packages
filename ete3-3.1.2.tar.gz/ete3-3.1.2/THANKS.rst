Current Team 
--------------
- Jaime Huerta-Cepas - EMBL (huerta@embl.de)
- Francois Serra - CNAG (EvolTree/ete-evol)  
- Renato Alves - EMBL (maintainer)

with greatly appreciated contributions from:
--------------------------------------------

- Finlay Maguire - Python3 ports 
- Keith Hughitt - Python3 ports  
- Shankar Vembu - fast tree reconciliation method
- Alexandros Pittis - testing
- François Serra - EvolTree
- Marina Marcet - help with PhylomeDB API and TreeKO tests
- Salvador Capella - maintainer of phylomedb API
- Ivan Denisov - help with phylomedb webplugin
- Joaquín Dopazo - original author
- Toni Gabaldon - original author
  
